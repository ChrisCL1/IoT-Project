create database reconocimiento_facial;
show databases;
USE reconocimiento_facial;

create table estudiantes (
  idUser INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(255) NOT NULL,
  primer_apellido VARCHAR(255) NOT NULL,
  segundo_apellido VARCHAR(255) NOT NULL,
  correo VARCHAR(255) NOT NULL,
  matricula VARCHAR(255) NOT NULL,
  grado VARCHAR(255) NOT NULL,
  grupo VARCHAR(255) NOT NULL,
  carrera VARCHAR(255) NOT NULL,
  fotografia LONGBLOB,
CONSTRAINT pk_estudiantes_idUser PRIMARY KEY (idUser),
  CONSTRAINT uk_estudiantes_matricula UNIQUE (matricula)
  );
  
 INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Hageo Juda', 'Balam', 'Mendez', '2109012@upy.edu.mx', '2109012', '4°', 'A', 'Ingeniería de Datos', null);

INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Miguel Angel', 'Bastarrachea', 'Carballo', '2009009@upy.edu.mx', '2009009', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Angel Adrian', 'Campos', 'Borges', '2109021@upy.edu.mx', '2109021', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Samantha', 'Castro', 'Echeverria', '2109028@upy.edu.mx', '2109028', '4°', 'A', 'Ingeniería de Datos', null);   

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Karla', 'Delgado', 'Avendaño', '2109050@upy.edu.mx', '2109050', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Julio Ernesto' ,'Dzul','Dzib', '2009048@upy.edu.mx', '2009048', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Carlo Alejandro', 'Ek', 'Palomo', '2109058@upy.edu.mx', '2109058', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Juan Antonio', 'Fernandez', 'Cruz', '2109061@upy.edu.mx', '2109061', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Hector Emiliano', 'Gonzalez', 'Martinez', '2109077@upy.edu.mx', '2109077', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Luis David','Martínez', 'Gutiérrez', '2109099@upy.edu.mx', '2109099', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Sonia Estefania', 'Mendia', 'Martinez', '2109104@upy.edu.mx', '2109104', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Juliana Alejandra', 'Ramayo', 'Cardoso', '2109128@upy.edu.mx', '2109128', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Angel David', 'Sansores', 'Cruz', '2109139@upy.edu.mx', '2109139', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('José Manuel', 'Solano', 'Ochoa', '2009127@upy.edu.mx', '2009127', '4°', 'A', 'Ingeniería de Datos', null);

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Yahir Benjamin','Sulu', 'Chi', '2109145@upy.edu.mx', '2109145', '4°', 'A', 'Ingeniería de Datos', null);  

  INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia)
VALUES ('Priscila Guadalupe', 'Tzuc', 'Alonso', '2109148@upy.edu.mx', '2109148', '4°', 'A', 'Ingeniería de Datos', null);
  
-- Generar tabla de estudiantes
SELECT * FROM estudiantes;

-- Tabla 2
  
CREATE TABLE asistencias(
idAsistencia INT NOT NULL AUTO_INCREMENT,
  idUser INT NOT NULL,
  fecha DATE,
  hora_entrada DATETIME,
  hora_salida DATETIME,
  asistencia BOOLEAN,
CONSTRAINT pk_asistencias_idAsistencia PRIMARY KEY (idAsistencia),
  CONSTRAINT fk_asistencias_idUser FOREIGN KEY (idUser) REFERENCES estudiantes(idUser)
  );

-- Generar Tabla 2 unida
SELECT estudiantes.idUser, estudiantes.primer_apellido, estudiantes.segundo_apellido, estudiantes.nombre, asistencias.fecha, asistencias.asistencia, asistencias.hora_entrada, asistencias.hora_salida 
FROM estudiantes 
JOIN asistencias 
ON estudiantes.idUser = asistencias.idUser 
ORDER BY asistencias.fecha DESC;


-- Tabla 3 
CREATE TABLE asistencia_grupal (
  id_asistencia_grupal INT NOT NULL AUTO_INCREMENT,
  fecha DATE,
  asistencia BOOLEAN,
  CONSTRAINT pk_user_id_asistencia_grupal PRIMARY KEY (id_asistencia_grupal)
  );
  
-- Generar tabla 3
SELECT * FROM asistencia_grupal;