import tkinter as tk
from tkinter import ttk
from tkcalendar import DateEntry
import mysql.connector
import maincode

# Crear la ventana y configurar el fondo, tamao y titulo
root = tk.Tk()
root.title("Lista de asistencia por visualizacion artificial")
root.geometry("800x600")
root.configure(bg="#f2deff")
root.columnconfigure(0, weight=2)
root.columnconfigure(15, weight=2)
root.rowconfigure(0, weight=1)
root.rowconfigure(15, weight=1)


######################################################## Conexion con la base de datos ########################################################

# Variables por defecto
default_host = "127.0.0.1"
default_user = "root"
default_password = "123456"
default_db = "reconocimiento_facial"
default_port = "3307"
# Funcion para conectarse a la base de datos
def conectar():
    host = host_entry.get()
    user = user_entry.get()
    password = password_entry.get()
    database = database_entry.get()
    port = port_entry.get()
    try:
        # Intentar conectarse a la base de datos
        cnx = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database,
            port=port
        )
        # Cerrar la conexion
        cnx.close()
        # Mostrar un mensaje de �xito
        resultado_label.config(text="Connected")
    except:
        # Mostrar un mensaje de error
        resultado_label.config(text="Error while connecting")

# Crear los widgets
widget_bg = "#fcf8d9"

host_label = tk.Label(root, text="Host:", bg = widget_bg, width=10)
host_entry = tk.Entry(root, width=30)
host_entry.insert(0, default_host)

port_label = tk.Label(root, text="Port:", bg = widget_bg, width=10)
port_entry = tk.Entry(root, width=30)
port_entry.insert(0, default_port)

user_label = tk.Label(root, text="User:", bg = widget_bg, width=10)
user_entry = tk.Entry(root, width=30)
user_entry.insert(0, default_user)

password_label = tk.Label(root, text="Password:", bg = widget_bg, width=10)
password_entry = tk.Entry(root, show="*", width=30)
password_entry.insert(0, default_password)

database_label = tk.Label(root, text="Database:", bg = widget_bg, width=10)
database_entry = tk.Entry(root, width=30)
database_entry.insert(0, default_db)

boton_conectar = tk.Button(root, text="Connect", bg = widget_bg, command=conectar)
resultado_label = tk.Label(root, text="",  bg = widget_bg)

# Ubicar los widgets en la ventana
host_label.grid(row=5, column=1)
host_entry.grid(row=5, column=2)
port_label.grid(row=6, column=1)
port_entry.grid(row=6, column=2)

user_label.grid(row=7, column=1)
user_entry.grid(row=7, column=2)
password_label.grid(row=8, column=1)
password_entry.grid(row=8, column=2)
database_label.grid(row=9, column=1)
database_entry.grid(row=9, column=2)
boton_conectar.grid(row=10, column=2, columnspan=1)
resultado_label.grid(row=11, column=2, columnspan=1)


#root.columnconfigure(1, weight=1)




######################################################## Lista desplegable Entrada/Salida ########################################################


# Separacion de la database y la lista desplegable
root.columnconfigure(4, weight=1)

# Crear el label para indicar la lista desplegable
entrada_label = tk.Label(root, text="Assistance Type:", bg = widget_bg, width=17)

# Crear la lista desplegable con algunos valores y seleccionar la opcion 1 por defecto
entrada_values = ["Entrada", "Salida"]
combo = ttk.Combobox(root, values=entrada_values, state='readonly', width=12)
combo.current(0)

# Acomodar los widgets en la ventana usando pack
entrada_label.grid(row=5, column=5)
combo.grid(row=5, column=6)

valor_seleccionado = combo.get()





######################################################## Calendario ########################################################

# Crear el label para indicar la fecha
fecha_label = tk.Label(root, text="Select a date:", bg = widget_bg, width=17)
fecha_label.grid(row=7, column=5)

# Crear el calendario desplegable
calendario = DateEntry(root, date_pattern="yyyy-mm-dd", state="readonly", bg = widget_bg, width=12)
calendario.grid(row=7, column=6)

fecha = calendario.get_date()













######################################################## Correr el codigo main ########################################################

def start():
    #values = [host_entry.get(), user_entry.get(), password_entry.get(), database_entry.get(), port_entry.get(), combo.get(), calendario.get_date()]
    maincode.main(host_entry.get(), user_entry.get(), password_entry.get(), database_entry.get(), port_entry.get(), combo.get(), calendario.get_date())



boton_iniciar = tk.Button(root, text="Launch program", bg = widget_bg, command=start, height=3)


boton_iniciar.grid(row=13, column=5, columnspan=2)


















# Correr el loop principal de la ventana
root.mainloop()




