import face_recognition
import cv2
import numpy as np
from datetime import datetime
from cmath import sqrt
from sqlite3 import DatabaseError
import mysql.connector
import decodificador


def main(dbhost, dbuser, dbpassword, dbdatabase, dbport, value, date):

    if (value == "Salida"):
        entrada = False 
    else:
        entrada = True

    # Estableciendo conexion con la base de datos 
    mydb = mysql.connector.connect(
            host=dbhost,
            user=dbuser,
            password=dbpassword,
            database=dbdatabase,
            port=dbport
        )
    
    # Seleccionando informacion relevante de cada alumno para utilizar. Se selecciona su ID de la tabla estudiantes, matricula, y fotografia para usarse de asistencia+
    mycursor = mydb.cursor()
    sql = "SELECT idUser, matricula, fotografia FROM estudiantes"
    mycursor.execute(sql)
    myresult = mycursor.fetchall()
    

    video_capture = cv2.VideoCapture(0)


    #### Getting current directory of the project folder

    # Creating data of the students to order the image file respectively to the database
    # Estudiantes = [[matricula, nombre, imagen.jpg]]
    # Estudiantes = [[idUser, matricula, imagen, imagen decodificada]]

    estudiantes = []

    for i in range(len(myresult)): # Cada i es una row de la tabla estudiante
        estudiantes.append([])  # Los estudiantes se guardaran localmente en el codigo, mediante una matriz
        for j in range(len(myresult[i])):  # Para cada estudiante en la tabla, se guarda el idUser, matricula e imagen en binario
            estudiantes[i].append(myresult[i][j])

        # Posteriormente, para cada alumno, se decodifica el binario de su fotografia y se agrega a su lista como un array de numpy
        estudiantes[i].append(decodificador.decodificador_array(estudiantes[i][2]))



    # Variables below will be used by the video capturer
    known_faces_ID = []
    known_faces_names = []  # Creating a list variable for the names known
    known_face_encoding = []  # Creating a list where the encoded faces will be.

 


    ## Populating the two lists above
    ## Using try and except to check for a missing image, if missing, it will take a null photo

    for i in range(len(estudiantes)):
        known_faces_ID.append(estudiantes[i][0])
        known_faces_names.append(estudiantes[i][1]) # Getting student names
        known_face_encoding.append(face_recognition.face_encodings(estudiantes[i][3])[0]) # Encoding faces of the images

    students = known_faces_names.copy()

    # Locations of the faces
 
    face_locations = []
    face_encodings = []
    face_names = []
    s=True
 
    # When day starts, dayAttendance is = 0, this will insert a new row that includes the date and a value of 0 to the asistencia_grupal table 

    try:
        sql = "SELECT max(id_asistencia_grupal) FROM asistencia_grupal" 
        mycursor.execute(sql)
        maxID = mycursor.fetchall()
        currentRowID = maxID[0][0] + 1 # Additionally, it will calculate the primary key ID of the asistencia_grupal table to stop duplicates from happening

    except:
        currentRowID = 1

    
    sql = "INSERT INTO asistencia_grupal (fecha, asistencia) VALUES (%s, %s)"
    values = (date, 0)
    mycursor.execute(sql, values)
    mydb.commit()


    while True:
        _,frame = video_capture.read()
        small_frame = cv2.resize(frame,(0,0),fx=0.25,fy=0.25)
        rgb_small_frame = small_frame[:,:,::-1]
        if s:
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame,face_locations)
            face_names = []
            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(known_face_encoding,face_encoding)
                name=["",0]
                face_distance = face_recognition.face_distance(known_face_encoding,face_encoding)
                best_match_index = np.argmin(face_distance)
                if matches[best_match_index]:
                    name[0] = known_faces_names[best_match_index]
                    name[1] = known_faces_ID[best_match_index]
 
                face_names.append(name[0])
                if name[0] in known_faces_names:
                    font = cv2.FONT_HERSHEY_TRIPLEX
                    bottomLeftCornerOfText = (19,46)
                    fontScale              = 1.25
                    fontColor              = (0,163,255)
                    thickness              = 2
                    lineType               = 2
                
                    cv2.rectangle(frame, (10, 55),(200,10),(139,12,93), -1)

                    cv2.putText(frame,name[0], 
                        bottomLeftCornerOfText, 
                        font, 
                        fontScale,
                        fontColor,
                        thickness,
                        lineType)

     # ------
                    if name[0] in students:
                        # Students array keep track of students that haven't been detected by the camera
                        # When detected, their name is removed
                        students.remove(name[0])

                        # The total assistance of the group is calculated by substracting the total amount of students not recognized of the total students
                        dayAttendance = len(estudiantes) - len(students)

                        # If dayAttendance is not 0, then it is greater. Table will be updated accordingly to the current row and date
                        sql = "UPDATE asistencia_grupal SET asistencia = %s WHERE fecha = %s AND id_asistencia_grupal = %s"
                        values = (dayAttendance, date, currentRowID)
                        mycursor.execute(sql, values)
                        mydb.commit()

                        #print(f"A total of {len(estudiantes) - len(students)} students have attended")

                        if entrada:
                            sql = "INSERT INTO asistencias (idUser, fecha, hora_entrada, asistencia) VALUES (%s, %s, %s, %s)"
                            values = (name[1],date,datetime.now(), True)
                            mycursor.execute(sql, values)
                            mydb.commit()
                        else: 
                            sql = "INSERT INTO asistencias (idUser, fecha, hora_salida, asistencia) VALUES (%s, %s, %s, %s)"
                            values = (name[1],date,datetime.now(), True)
                            mycursor.execute(sql, values)
                            mydb.commit()

    # -------
        cv2.imshow("Sistema de Asistencia por Visualizacion Artificial",frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
 
    video_capture.release()
    cv2.destroyAllWindows()
    f.close()




#main('127.0.0.1', 'root','123456','reconocimiento_facial','3307','Salida',"2023-04-15")