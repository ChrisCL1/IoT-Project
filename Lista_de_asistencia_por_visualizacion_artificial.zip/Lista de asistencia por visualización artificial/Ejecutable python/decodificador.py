from PIL import Image
import io
import numpy as np

def decodificador_jpg(datos_binarios):
    stream = io.BytesIO(datos_binarios)
    imagen = Image.open(stream)
    stream_jpg = io.BytesIO()
    imagen.save(stream_jpg, format='JPEG')
    datos_jpg = stream_jpg.getvalue()
    return datos_jpg

def decodificador_array(datos_binarios):
    img = Image.open(io.BytesIO(datos_binarios))

    # Convert the binary image to a numpy array
    array = np.array(img)

    return array