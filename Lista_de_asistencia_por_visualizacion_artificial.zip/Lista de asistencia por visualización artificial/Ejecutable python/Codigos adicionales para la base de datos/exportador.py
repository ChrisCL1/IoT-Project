### ESTE CODIGO IMPORTA LAS IMAGENES LOCALES A LOS RESPECTIVOS ALUMNOS EN LA BASE DE DATOS.
### SE USA SI SE TIENEN LAS FOTOGRAFIAS DE LOS ALUMNOS CON SU RESPECTIVA MATRICULA COMO NOMBRE, Y SI ESTOS ALUMNOS ESTAN REGISTRADOS



import mysql.connector

def convertToBinaryData(filename):
    # Convert digital data to binary format
    with open(filename, 'rb') as file:
        binaryData = file.read()
    return binaryData


def insertBLOB(photo, matricula):
    print("Inserting BLOB into python_employee table")
    try:
        mydb = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            password='123456',
            database='reconocimiento_facial',
            port='3307'
        )

        cursor = mydb.cursor()
        sql_insert_blob_query = "UPDATE estudiantes SET fotografia = %s WHERE matricula = %s"

        empPicture = convertToBinaryData(photo)

        # Convert data into tuple format
        insert_blob_tuple = (empPicture, matricula)
        result = cursor.execute(sql_insert_blob_query, insert_blob_tuple)
        mydb.commit()
        print("Image and file inserted successfully", result)
       

    except mysql.connector.Error as error:
        print("Failed inserting BLOB data into MySQL table {}".format(error))

    finally:
        if mydb.is_connected():
            cursor.close()
            mydb.close()
            print("MySQL connection is closed")



### Favor de actualizar el directorio


matriculas = ['2009009', '2009048', '2009127', '2109012', '2109021', '2109028', '2109050', '2109058', '2109061', '2109077', '2109099', '2109104', '2109128', '2109139', '2109145', '2109148']

for i in matriculas:
    insertBLOB(f"C:\\Users\\julio\\Desktop\\Ejecutable estancia\\Codigos adicionales para la base de datos\\photos\\{i}.jpg", i)



#insertBLOB("C:\\Users\\julio\\Desktop\\Ejecutable estancia\\Estancia old\\photos\\2009048.jpg", 2009048)
