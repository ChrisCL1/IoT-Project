import tkinter as tk
from tkinter import ttk
from tkcalendar import DateEntry
import mysql.connector


# Crear la ventana y configurar el fondo, tama�o y titulo
root = tk.Tk()
root.title("Lista de asistencia por visualizacion artificial")
root.geometry("800x600")
root.configure(bg="#f2deff")


#### Conexion con la base de datos ####

# Variables por defecto
default_host = "localhost"
default_user = "root"
default_password = "Umi15031706-"
default_db = "reconocimiento_facial"

# Funcion para conectarse a la base de datos
def conectar():
    host = host_entry.get()
    user = user_entry.get()
    password = password_entry.get()
    database = database_entry.get()

    try:
        # Intentar conectarse a la base de datos
        cnx = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        # Cerrar la conexion
        cnx.close()
        # Mostrar un mensaje de �xito
        resultado_label.config(text="Conexion exitosa!")
    except:
        # Mostrar un mensaje de error
        resultado_label.config(text="Error al conectar")

# Crear los widgets
widget_bg = "#fcf8d9"

host_label = tk.Label(root, text="Host:", bg = widget_bg)
host_entry = tk.Entry(root)
host_entry.insert(0, default_host)

user_label = tk.Label(root, text="User:", bg = widget_bg)
user_entry = tk.Entry(root, width=30)
user_entry.insert(0, default_user)

password_label = tk.Label(root, text="Password:", bg = widget_bg)
password_entry = tk.Entry(root, show="*", width=30)
password_entry.insert(0, default_password)

database_label = tk.Label(root, text="Database:", bg = widget_bg)
database_entry = tk.Entry(root, width=30)
database_entry.insert(0, default_db)

boton_conectar = tk.Button(root, text="Conectar", bg = widget_bg, command=conectar)
resultado_label = tk.Label(root, text="",  bg = widget_bg)

# Ubicar los widgets en la ventana
host_label.grid(row=0, column=0)
host_entry.grid(row=0, column=1)
user_label.grid(row=1, column=0)
user_entry.grid(row=1, column=1)
password_label.grid(row=2, column=0)
password_entry.grid(row=2, column=1)
database_label.grid(row=3, column=0)
database_entry.grid(row=3, column=1)
boton_conectar.grid(row=4, column=1, columnspan=1)
resultado_label.grid(row=5, column=1, columnspan=2)

# Ejecutar el loop principal de la ventana
root.mainloop()