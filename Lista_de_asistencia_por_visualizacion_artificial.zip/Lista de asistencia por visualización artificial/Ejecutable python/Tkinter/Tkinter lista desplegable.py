import tkinter as tk
from tkinter import ttk

# Crear la ventana
root = tk.Tk()
root.title("Mi App")
root.geometry("400x200")

# Crear el label para indicar la lista desplegable
label = tk.Label(root, text="Por favor seleccione una opcion:")

# Crear la lista desplegable con algunos valores y seleccionar la opcion 1 por defecto
values = ["Opcion 1", "Opcion 2", "Opcion 3"]
combo = ttk.Combobox(root, values=values, state='readonly')
combo.current(0)

# Funcion adicional que se ejecuta cuando se presiona el bot�n
def mi_funcion():
    valor_seleccionado = combo.get()
    print("Valor seleccionado:", valor_seleccionado)

# Crear el boton para correr la funcion adicional
button = tk.Button(root, text="Ejecutar funcion", command=mi_funcion)

# Acomodar los widgets en la ventana usando pack
label.pack(side="left", padx=10, pady=10)
combo.pack(side="left", padx=10, pady=10)
button.pack()

# Correr el loop principal de la ventana
root.mainloop()
