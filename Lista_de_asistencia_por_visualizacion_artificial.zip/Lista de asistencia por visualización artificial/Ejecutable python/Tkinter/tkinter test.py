#### Lista desplegable que contiene entrada / salida ####


# Crear el label para indicar la lista desplegable
label = tk.Label(root, text="Por favor seleccione una opcion:")

# Crear la lista desplegable con algunos valores y seleccionar la opcion 1 por defecto
values = ["Opcion 1", "Opcion 2", "Opcion 3"]
combo = ttk.Combobox(root, values=values, state='readonly')
combo.current(0)

# Funcion adicional que se ejecuta cuando se presiona el bot�n
def lista_funcion():
    valor_seleccionado = combo.get()
    print("Valor seleccionado:", valor_seleccionado)

# Crear el boton para correr la funcion adicional
button = tk.Button(root, text="Ejecutar funcion", command=lista_funcion)

# Acomodar los widgets en la ventana usando pack
label.pack(side="left", padx=10, pady=10)
combo.pack(side="left", padx=10, pady=10)
button.pack()









#### Calendario ####

# Funcion
def calendario_funcion():
    fecha = calendario.get_date()
    print("Fecha seleccionada:", fecha)


# Crear el label para indicar la fecha
label = tk.Label(root, text="Selecciona la fecha de asistencia:")
label.pack(pady=10)

# Crear el calendario desplegable
calendario = DateEntry(root, date_pattern="yyyy-mm-dd", state="readonly")
calendario.pack(pady=10)






# Crear el bot�n para ejecutar la funci�n adicional
boton = tk.Button(root, text="Seleccionar fecha", command=calendario_funcion)
boton.pack(pady=10)

# Ejecutar el loop principal de la ventana
root.mainloop()
