import tkinter as tk
from tkinter import ttk
from tkcalendar import DateEntry

def mi_funcion():
    fecha = calendario.get_date()
    print("Fecha seleccionada:", fecha)

# Crear la ventana
root = tk.Tk()
root.title("Seleccionar fecha")
root.geometry("300x200")
root.configure(bg="#f2deff")

# Crear el label para indicar la fecha
label = tk.Label(root, text="Selecciona una fecha:")
label.pack(pady=10)

# Crear el calendario desplegable
calendario = DateEntry(root, date_pattern="yyyy-mm-dd", state="readonly")
calendario.pack(pady=10)

# Crear el bot�n para ejecutar la funci�n adicional
boton = tk.Button(root, text="Seleccionar fecha", command=mi_funcion)
boton.pack(pady=10)

# Ejecutar el loop principal de la ventana
root.mainloop()
