### Este codigo es una prueba para obtener las imagenes de la base de datos mysql, decodificarlas y descargarlas. Se pondra en uso para el codigo final

import mysql.connector


def write_file(data, filename):
    # Convert binary data to proper format and write it on Hard Disk
    with open(filename, 'wb') as file:
        file.write(data)


def readBLOB(idUser, fotografia):
    print("Reading BLOB data from python_employee table")

    try:
        mydb = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            password='123456',
            database='reconocimiento_facial',
            port='3307'
        )

        cursor = mydb.cursor()
        sql_fetch_blob_query = """SELECT * from estudiantes where idUser = %s"""

        cursor.execute(sql_fetch_blob_query, (idUser,))
        record = cursor.fetchall()
        for row in record:
            print("Id = ", row[0], )
            print("Name = ", row[1])
            image = row[9]
            print("Storing employee image\n")
            write_file(image, fotografia)

    except mysql.connector.Error as error:
        print("Failed to read BLOB data from MySQL table {}".format(error))

    finally:
        if mydb.is_connected():
            cursor.close()
            mydb.close()
            print("MySQL connection is closed")


readBLOB(5, "C:\\Users\\julio\\Desktop\\Ejecutable estancia\\tilin4.jpg")
