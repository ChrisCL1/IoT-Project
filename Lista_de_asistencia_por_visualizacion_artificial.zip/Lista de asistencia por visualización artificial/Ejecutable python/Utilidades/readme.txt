#####

Codigos antiguos que no tienen utilidad en el funcionamiento 
del programa, pero fueron utiles para aprender el proceso 
necesario y/o se juntaron con el trabajo final en otros archivos