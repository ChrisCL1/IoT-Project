from cmath import sqrt
from sqlite3 import DatabaseError
import mysql.connector

# Creating the database instance
mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    password='Umi15031706-',
    database='reconocimiento_facial'
)

mycursor = mydb.cursor()
sql = "SELECT matricula, nombre FROM asistencias"
mycursor.execute(sql)
myresult = mycursor.fetchall()
