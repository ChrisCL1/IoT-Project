
/*
document.addEventListener('DOMContentLoaded', () => {
  const botonEncenderCamara = document.getElementById('encender-camara');
  const video = document.getElementById('video');
  const botonTomarFoto = document.getElementById('tomar-foto');
  const botonApagarCamara = document.getElementById('apagar-camara');
  let stream = null;

  botonEncenderCamara.addEventListener('click', async () => {
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = stream;
      video.play();

      // Mostrar el botón de apagar-camara
      botonApagarCamara.style.display = 'inline-block';

      video.addEventListener('loadedmetadata', () => {
        // Mostrar el botón de tomar foto
        botonTomarFoto.style.display = 'inline-block';
      });
    } catch (error) {
      console.error(error);
    }
  });

  botonApagarCamara.addEventListener('click', () => {
    video.pause();
    video.srcObject = null;
    stream.getTracks()[0].stop();

    // Ocultar el botón de tomar foto
    botonTomarFoto.style.display = 'none';

    // Ocultar el botón de apagar cámara
    botonApagarCamara.style.display = 'none';
  });

  botonTomarFoto.addEventListener('click', () => {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    const foto = canvas.toDataURL('image/png');
    document.getElementById('foto-tomada').src = foto;

    // Enviar imagen al servidor usando AJAX
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'subir_foto.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send('foto=' + encodeURIComponent(foto));
      if (this.status === 200) {
        console.log(this.responseText);
      }
    
    xhr.onerror = function() {
      console.log('Error al procesar la solicitud');
    };
    xhr.send('foto=' + encodeURIComponent(foto));
  });
});

*/