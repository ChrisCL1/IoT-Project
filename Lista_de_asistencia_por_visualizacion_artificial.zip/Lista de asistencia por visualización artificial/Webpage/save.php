<?php
// Datos de conexión a la base de datos
$host = "127.0.0.1:3307";
$user = "root";
$password = "123456";
$database = "reconocimiento_facial";

// Conectando y seleccionando la base de datos
$conn = mysqli_connect($host, $user, $password, $database) or die("Error al conectar a la base de datos");

// Recibiendo los datos del formulario
$fotografia = $_POST['fotografia'];
$nombre = $_POST['nombre'];
$primer_apellido = $_POST['primer_apellido'];
$segundo_apellido = $_POST['segundo_apellido'];
$correo = $_POST['correo'];
$matricula = $_POST['matricula'];
$grado = $_POST['grado'];
$grupo = $_POST['grupo'];
$carrera = $_POST['carrera'];

// Convirtiendo la imagen a su equivalente binario usando file_get_contents()
$fotografia_binaria = file_get_contents($fotografia);

// Preparando la consulta SQL
$sql = "INSERT INTO estudiantes (nombre, primer_apellido, segundo_apellido, correo, matricula, grado, grupo, carrera, fotografia) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

// Preparando la sentencia
$stmt = mysqli_prepare($conn, $sql);

// Asignando los parámetros
mysqli_stmt_bind_param($stmt, "sssssssss", $nombre, $primer_apellido, $segundo_apellido, $correo, $matricula, $grado, $grupo, $carrera, $fotografia_binaria);

// Ejecutando la sentencia
if (mysqli_stmt_execute($stmt)) {
    echo "Datos guardados correctamente";
} else {
    echo "Error al guardar los datos";
}

// Cerrando la conexión y la sentencia
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>

