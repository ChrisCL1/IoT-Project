from PIL import Image
import io
import numpy as np

def decodificador_array(datos_binarios):
    img = Image.open(io.BytesIO(datos_binarios))

    # Convert the binary image to a numpy array
    array = np.array(img)

    return array


